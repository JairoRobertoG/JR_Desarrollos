﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JR_Desarrollos.clParent
{
    public class Parent
    {
        public Parent()
        {
        }

        public static string GetIntToString(int x)
        {
            return x.ToString();
        } 

    }
}